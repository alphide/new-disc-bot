import discord
import discord.utils
from discord.ext import commands
from discord.ext.commands import has_permissions

class General(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(pass_context=True, aliases=['c', 'C'])
    @has_permissions(manage_messages=True,
                     manage_roles=True)  # decorator so that only users with certain permissions can run the command
    async def clearmsg(self, ctx, num=100):
        channel = ctx.message.channel
        msgs = []
        # appends the messages in msgs list
        async for i in channel.history(limit=num + 1):  # deletes own command message
            msgs.append(i)

        await channel.delete_messages(msgs)  # deletes msgs list
        if num == 1:
            await ctx.send(f'{num} message has been cleared by {ctx.message.author.mention}', delete_after=3)
        else:
            await ctx.send(f'{num} messages have been cleared by {ctx.message.author.mention}', delete_after=3)

    @commands.command(pass_context=True, aliases=['ar'])
    @has_permissions(manage_messages=True, manage_roles=True)
    async def role(self, ctx, user: discord.Member, role: discord.Role):
        if role in user.roles:
            await ctx.send(f'{user.mention} already has this role!')
        else:
            await user.add_roles(role)
            await ctx.send(f'{role.mention} has been given to {user.mention}')

    @commands.command(pass_context=True, aliases=['rr'])
    @has_permissions(manage_messages=True, manage_roles=True)
    async def removerole(self, ctx, user: discord.Member, role: discord.Role):
        if role not in user.roles:
            await ctx.send(f'{user.mention} did not have {role.mention} to begin with!')
        else:
            await user.remove_roles(role)
            await ctx.send(f'{role.mention} has been removed from {user.mention}')

    @commands.command()
    @has_permissions(manage_messages=True, manage_roles=True)
    async def mute(self, ctx, user: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="Muted")
        await user.add_roles(role)
        await ctx.send(f"{user.mention} has been muted")

    @commands.command()
    @has_permissions(manage_messages=True, manage_roles=True)
    async def unmute(self, ctx, user: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="Muted")
        await user.remove_roles(role)
        await ctx.send(f"{user.mention} has been unmuted")

def setup(bot):
    bot.add_cog(General(bot))